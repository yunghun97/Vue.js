<template>
  <h2>{{ total }}</h2>
</template>

<script>
export default {
  props: ["total"],
};
</script>

<style></style>
