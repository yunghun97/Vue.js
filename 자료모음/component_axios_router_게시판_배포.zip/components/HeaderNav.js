export default {
  template: `
    <div class="header">
    <router-link to="/"><img src="./img/ssafy_logo.png" class="ssafy_logo" /></router-link>
        <p class="logo">게시판</p>
    </div>`
};
