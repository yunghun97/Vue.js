export default {
  template: `
    <div>
        <ul>
            <li><router-link to="/register">글 등록</router-link></li>
            <li><router-link to="/list">글 목록</router-link></li>
        </ul>
    </div>
    `
};
