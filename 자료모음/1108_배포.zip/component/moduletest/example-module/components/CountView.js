let data = {
  count: 0,
};
export default {
  template: '#CountView',
  data() {
    return data;
  },
};
