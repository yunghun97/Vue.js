export default {
  template: '#ChildComp',
  props: ['area', 'msg'],
};
