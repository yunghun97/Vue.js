export default {
  template: '<h2>전역 컴포넌트임</h2>',
};
