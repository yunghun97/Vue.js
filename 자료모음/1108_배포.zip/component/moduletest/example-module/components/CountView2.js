export default {
  template: '#CountView',
  data() {
    return {
      count: 0,
    };
  },
};
