export default {
  template: '<div>메인 페이지</div>',
};
