export default {
  template: '<div>갤러리 게시판</div>',
};
