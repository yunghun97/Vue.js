export default {
  template: '<div>자유 게시판</div>',
};
